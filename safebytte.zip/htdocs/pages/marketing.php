<section class="hero-section" style="background: #000000; border-bottom: none;">
    <h1>WELCOME TO SAFEBYTE</h1>
    <h2>THE ULTIMATE DEFENSE AGAINST A SURVEILLED WORLD.</h2>
    <p>SAFEBYTE provides innovative, user-friendly solutions to secure VPN gateways—empowering you to safeguard personal data and physical spaces.</p>
    <a href="index.php?page=pricing" class="btn-primary">EXPLORE SOLUTIONS</a>
</section>